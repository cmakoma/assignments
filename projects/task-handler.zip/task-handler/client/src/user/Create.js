import React from 'react';
import Form from "./Form"

const Create = () => {
    return (
        <div>
            <h1>create a task here</h1>
    
            <Form />
        </div>
    );
};

export default Create;