import React, { Component } from 'react'
import NavbarUser from "./navbar/NavbarUser"


class User extends Component {
    render() {
        return (
            <div>
                <NavbarUser />

            </div>
        );
    }
}

export default User;