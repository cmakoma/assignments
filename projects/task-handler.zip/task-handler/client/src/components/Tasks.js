import React from 'react';


const Tasks = () => {
    return (
        <div>
            <h1>this is the tasks page</h1>
        </div>
    );
};

export default Tasks;